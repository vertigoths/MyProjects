import java.awt.event.ActionEvent;

public class ActionListener implements java.awt.event.ActionListener
{
	
	
	public ActionListener() 
	{
		
	}
	
	
	public void actionPerformed(ActionEvent e) 
	{
		System.out.println("hello");
	}
}
